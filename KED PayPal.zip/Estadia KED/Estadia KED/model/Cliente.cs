﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Estadia_KED
{
    public class Cliente
    {
        
        public String correo { get; set; }
        public String telefono { get; set; }
        public String contrasena{ get; set; }
    }
}